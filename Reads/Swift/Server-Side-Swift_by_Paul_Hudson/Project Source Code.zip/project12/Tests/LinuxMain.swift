import XCTest
@testable import project11Tests

XCTMain([
     testCase(project11Tests.allTests),
])
