import HeliumLogger
import Kitura
import KituraStencil
import Stencil

HeliumLogger.use()

let router = Router()
let namespace = Namespace()

namespace.registerFilter("reverse") { (value: Any?) in
    guard let unwrapped = value as? String else { return value }
    let result = String(unwrapped.characters.reversed())
    return result
}

namespace.registerSimpleTag("debug") { context in
    return String(describing: context.flatten())
}

namespace.registerTag("autoescape", parser: AutoescapeNode.parse)

router.setDefault(templateEngine: StencilTemplateEngine(namespace: namespace))

router.get("/") {
    request, response, next in
    defer { next() }

    let haters = "hating"
    let names = ["Taylor", "Paul", "Justin", "Adele"]
    let hamsters = [String]()
    let quote = "He thrusts his fists against the posts and still insists he sees the ghosts"

    let context: [String: Any] = ["haters": haters, "names": names, "hamsters": hamsters, "quote": quote]
    try response.render("home", context: context)
}

Kitura.addHTTPServer(onPort: 8090, with: router)
Kitura.run()
